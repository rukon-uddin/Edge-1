1) Download VGG annotator - https://www.robots.ox.ac.uk/~vgg/software/via/downloads/via-2.0.11.zip  (I have provided the software)
2) After downloading the software, open via.htm
3) Now select region shape to polygon
4) give a name to your project (any)
5) Click on (add file) and select all the images in the image directory
6) Click on attributes, select region Attribute, give attribute name as 'name' (dont include the quatations)
7) click on the + button
8) select Type as dropdown
9) Now you need to put you class names
10) Next you need to draw polygons on each of the object.
11) After completing, go to annotation->export as csv